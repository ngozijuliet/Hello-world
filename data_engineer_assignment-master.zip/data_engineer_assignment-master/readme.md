# Project Tracr - Data Engineer Assignment

## Background:

As a data engineer your role is to work closely with our data scientists. You will be helping us build our next generation of products which will be based on data and machine learning. 

Good data science requires timely access to high-quality data feeds. We hope that by adding an expert data engineer to our team we can raise the quality of data available to the organization. 

This assignment is intended to see how you would approach an every-day data engineering problem. We expect that it should take approximately three hours to complete. Please try to get a fully working system: "practical" and "done" is more important than "perfect".

Your work will be assessed on a number of criteria:
* Does it work as required? We will follow any instructions you have provided and attempt to re-run your project. If you provided any tests we will run them.
* We will assess code-quality - for example correct idiomatic use of Python, appropriate testing, readability and style.

Please submit your work back as a zip file. Include any file or component which is needed to re-run the assignment such as scripts and instructions. Please do not include any database internal files.

## Assignment:

Our data scientists are working on a new image classifier. They require a number of images in order to train the system. They have identified a public source of images which may be suitable at this URL:

http://groups.csail.mit.edu/vision/TinyImages/thumbnails64x64/

We want these images to be downloaded and placed into a database. The data scientists have determined that 1000 images will be sufficient for now, but more images may be required in the near future. It should be possible to re-run your script in order to fetch additional images.

Each image should be stored along with some metadata, such as URL from which the image was originally downloaded, the title of the image (if known), and a timestamp which identifies when the image was downloaded.

### Reading back the stored images

The team will require an easy way to access these images. Please provide a function in order to randomly retrieve images from the database:

The data scientists have proposed that you give them a function with approximately this signature: A function that will take no arguments but will return an iterator (or generator), in which each item represents one image. It does not matter if an image is produced more than once.

```python
def get_random_images()->Iterator[ImageStructure]:
    """Function that returns an iterator.
    Each iteration gives an instance of a data structure which contains the image + associated meta data.
    """ 
```
 You are required to define and implement "ImageStructure", which could be a class, dataclass, dict or any other Python structure sufficient for the purpose described. 

## Task Summary

 - Use the docker-compose file in this project to spin up a new postgres database.
 - Create an appropriate database schema - please provide a way for us to recreate this schema.
 - Write a script that imports a random sample of 1000 images into a the database. All of the images you download must me stored in records in the database.
 - Provide a python function which will allow the data scientists to iterate over the image collection. Each iteration should give a data structure containing a randomly chosen image from the database.
 - Provided some instructions which will enable us to execute your project.

# Requirements

We store all our data in a postgres database. The docker-compose.yaml configuration in this project will spin up a correctly configured database. You can see the user account, database and password in the docker-compose.yaml file.

 - Please use Python 3.6 or 3.7 as your main programming language. Some files in this project may help you set up a Python project.
 - You may also use shell-scripts, SQL and other tools.
 - If you want to use posrgres, please use the configuration provided. You can use any AWS (or other cloud) technologies if you prefer.
 - Please store additional metadata such as the URL from which each image was downloaded and a time-stamp when the image was fetched.
 - We will want to re-run the script ourselves, so so please make sure that all aspects of this assignment is easily rerunnable. It should be possible for us to re-create your schema and run your import script.



