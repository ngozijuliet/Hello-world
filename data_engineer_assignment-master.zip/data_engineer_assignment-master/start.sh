#!/usr/bin/env bash
docker-compose up --force-recreate
