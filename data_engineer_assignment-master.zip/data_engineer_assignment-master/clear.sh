#!/usr/bin/env bash
docker system prune --all