import unittest


class ExampleTest(unittest.TestCase):

    def test_example_0(self):
        pass
