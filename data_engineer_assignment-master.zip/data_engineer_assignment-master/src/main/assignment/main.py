def main():
    """
    You can customize this script.
    :return:
    """
    print ("Hello World!")